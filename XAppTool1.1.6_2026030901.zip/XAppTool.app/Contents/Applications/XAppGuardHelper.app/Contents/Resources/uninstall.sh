#! /bin/sh

sudo launchctl unload /Library/LaunchDaemons/com.better365.iFanOffline.SMC.Helper.plist
sudo rm /Library/LaunchDaemons/com.better365.iFanOffline.SMC.Helper.plist
sudo rm /Library/PrivilegedHelperTools/com.better365.iFanOffline.SMC.Helper
