#! /bin/sh

sudo launchctl unload /Library/LaunchDaemons/cn.better365.iFanControl.SMC.Helper.plist
sudo rm /Library/LaunchDaemons/cn.better365.iFanControl.SMC.Helper.plist
sudo rm /Library/PrivilegedHelperTools/cn.better365.iFanControl.SMC.Helper
